namespace loko.Resources.Styles;

public partial class Converters : ResourceDictionary
{
	public Converters()
	{
		InitializeComponent();
	}
}