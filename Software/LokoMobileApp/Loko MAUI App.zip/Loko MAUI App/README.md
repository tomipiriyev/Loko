# lokoApp

Need to add your own google maps api key to
Platforms/Android/Resources/Values/string.xml
Additionally, need to fix .csproj file with your own
CodesignProvision, ProvisioningType, CodesignKey,ApplicationId and such paremeters
