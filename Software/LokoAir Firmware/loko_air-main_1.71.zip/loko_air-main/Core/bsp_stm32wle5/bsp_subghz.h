#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void subghz_init(void);
void subghz_deinit(void);
void subghz_interrupt_handler(void);

#ifdef __cplusplus
}
#endif
