# cspg
C Settings Python Generator


This tool generate C code form JSON template and provice interfaces desribed in JSON file

