# The "LOG_"
Just Logger but development for embedded devices 
