#pragma once

#ifdef __cplusplus
extern "C" {
#endif

/* Exported constants --------------------------------------------------------*/

#define USE_BSP_DRIVER

/* Includes ------------------------------------------------------------------*/
#include "stm32wlxx_LoRa_E5_mini_radio.h"
#include <stdbool.h>

#ifdef __cplusplus
}
#endif
