#include "CppUTest/TestHarness.h"

#include <string.h>

#include "settings/settings.h"

/*----------------------------------------------------------------------------*/

void settings_setup_io(void);
settings_io_t *settings_get_io(void);
void settings_set_noise_on_page(void);

/*----------------------------------------------------------------------------*/
