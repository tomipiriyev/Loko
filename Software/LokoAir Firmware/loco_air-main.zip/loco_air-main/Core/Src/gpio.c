/**
  ******************************************************************************
  * @file    gpio.c
  * @brief   This file provides code for the configuration
  *          of all used GPIO pins.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "gpio.h"

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/*----------------------------------------------------------------------------*/
/* Configure GPIO                                                             */
/*----------------------------------------------------------------------------*/
/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

/** Configure pins as
        * Analog
        * Input
        * Output
        * EVENT_OUT
        * EXTI
*/
void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GNSS_EN_Pin|LORA_EN_Pin|LORA_RST_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GNSS_WAKEUP_GPIO_Port, GNSS_WAKEUP_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(VBAT_MEASURE_EN_GPIO_Port, VBAT_MEASURE_EN_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = CHARGER_STAT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(CHARGER_STAT_GPIO_Port, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = BUTTON_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(BUTTON_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PBPin PBPin PBPin PBPin */
  GPIO_InitStruct.Pin = GNSS_EN_Pin|LORA_EN_Pin|LORA_RST_Pin|VBAT_MEASURE_EN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = GNSS_WAKEUP_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GNSS_WAKEUP_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = GNSS_PPS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GNSS_PPS_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 2 */

bool bsp_gpio_is_button_pressed(void) {

	return HAL_GPIO_ReadPin(BUTTON_GPIO_Port, BUTTON_Pin) == GPIO_PIN_SET;
}

bool bsp_gpio_is_charger_high(void) {

	return HAL_GPIO_ReadPin(CHARGER_STAT_GPIO_Port, CHARGER_STAT_Pin) == GPIO_PIN_SET;
}

void bsp_gpio_led_on(void) {

	HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);
}

void bsp_gpio_led_off(void) {

	HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_SET);
}

void bsp_gpio_led_toggle(void) {

	HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
}

void bsp_gpio_gnss_on(void) {

	HAL_GPIO_WritePin(GNSS_EN_GPIO_Port, GNSS_EN_Pin, GPIO_PIN_SET);
}

void bsp_gpio_gnss_off(void) {

	HAL_GPIO_WritePin(GNSS_EN_GPIO_Port, GNSS_EN_Pin, GPIO_PIN_RESET);
}

void bsp_gpio_gnss_wakeup_enter(void) {

	HAL_GPIO_WritePin(GNSS_WAKEUP_GPIO_Port, GNSS_WAKEUP_Pin, GPIO_PIN_RESET);
}

void bsp_gpio_gnss_wakeup_leave(void) {

	HAL_GPIO_WritePin(GNSS_WAKEUP_GPIO_Port, GNSS_WAKEUP_Pin, GPIO_PIN_SET);
}

void bsp_gpio_lora_on(void) {

	HAL_GPIO_WritePin(LORA_EN_GPIO_Port, LORA_EN_Pin, GPIO_PIN_SET);
}

void bsp_gpio_lora_off(void) {

	HAL_GPIO_WritePin(LORA_EN_GPIO_Port, LORA_EN_Pin, GPIO_PIN_RESET);
}

void bsp_gpio_lora_reset_enter(void) {

	HAL_GPIO_WritePin(LORA_RST_GPIO_Port, LORA_RST_Pin, GPIO_PIN_RESET);
}

void bsp_gpio_lora_reset_leave(void) {

	HAL_GPIO_WritePin(LORA_RST_GPIO_Port, LORA_RST_Pin, GPIO_PIN_SET);
}


void bsp_gpio_vbat_measure_on(void) {

	HAL_GPIO_WritePin(VBAT_MEASURE_EN_GPIO_Port, VBAT_MEASURE_EN_Pin, GPIO_PIN_SET);
}

void bsp_gpio_vbat_measure_off(void) {

	HAL_GPIO_WritePin(VBAT_MEASURE_EN_GPIO_Port, VBAT_MEASURE_EN_Pin, GPIO_PIN_RESET);
}



/* USER CODE END 2 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
