/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "rtc.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "adc.h"
#include "usb_device.h"
#include "LOG_/log_.h"
#include "usbd_cdc_if.h"
#include "lwgps/lwgps.h"
#include <string.h>
#include "queue.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define LONG_PRES_TIME_MS					(3000UL)			/*<! Button hold timeout, milliseconds*/
#define NOFIX_TIMEOUT_MS    				(5*60 * 1000UL)		/*<! When GPS can't catch satellites during NOFIX_TIMEOUT_MS time(milliseconds), go to sleep for SLEEP_NOFIX_PERIOD_S */
#define SLEEP_PERIOD_S						(1/*min*/ * 60UL)	/*<! Sleep time, seconds*/
#define SLEEP_NOFIX_PERIOD_S				(1/*min*/ * 60UL)	/*<! Sleep time for non fix state, seconds*/
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* GNSS parser handle, contain all information about navigation */
lwgps_t hgnss;

/*RX queue for uarts stream */
#define GNSS_RX_QUEUE_SIZE         					(1024)
#define LORA_RX_QUEUE_SIZE         					(1024)
static QUEUE(_gnss_rx_queue, GNSS_RX_QUEUE_SIZE, uint8_t);
static QUEUE(_lora_rx_queue, LORA_RX_QUEUE_SIZE, uint8_t);

/* global variable for unknown purposes :) */
static uint32_t g_id1 = 0;
static uint32_t g_id2 = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* -------------------------------------------------------------------------- */

/* Called from Interrupt handler, byte receiving */
void gnss_byte_received(uint8_t byte) {

    static bool is_queue_full_dbg_display = false;

    if (queue_enqueue(QHEAD(_gnss_rx_queue), (uint8_t*)&byte, enqueue8) == false) {
        if (is_queue_full_dbg_display == false) {
            //LOG_ERROR("_gnss_rx_queue is full");
        }
        is_queue_full_dbg_display = true;
    } else {
        is_queue_full_dbg_display = false;
    }
}
/* -------------------------------------------------------------------------- */

/* Called from Interrupt handler, byte receiving */
void lora_byte_received(uint8_t byte) {

    static bool is_queue_full_dbg_display = false;

    if (queue_enqueue(QHEAD(_lora_rx_queue), (uint8_t*)&byte, enqueue8) == false) {
        if (is_queue_full_dbg_display == false) {
            //LOG_ERROR("RX1 queue is full");
        }

        is_queue_full_dbg_display = true;
    } else {
        is_queue_full_dbg_display = false;
    }
}
/* -------------------------------------------------------------------------- */

static void _shutdown(void) {

  LOG_DEBUG("Shutdown");

  bsp_gpio_led_off();
  bsp_gpio_gnss_off();
  bsp_gpio_lora_off();

  while(bsp_gpio_is_button_pressed()){
	  //Wait for release button to avoid wake-up
  }

  /* Clear Standby flag */
  __HAL_PWR_CLEAR_FLAG(PWR_FLAG_SB);

  /* Disable all used wake-up sources: PWR_WAKEUP_PIN1 */
  HAL_PWR_DisableWakeUpPin(PWR_WAKEUP_PIN1);

  /* Clear all related wake-up flags*/
  __HAL_PWR_CLEAR_FLAG(PWR_FLAG_WU);

  /* Enable WakeUp Pin PWR_WAKEUP_PIN1 connected to PA.0 */
  HAL_PWR_EnableWakeUpPin(PWR_WAKEUP_PIN1);


  bsp_rtc_wakeup_deactivate();

  /* Enter the Standby mode */
  HAL_PWR_EnterSTANDBYMode();
}
/* -------------------------------------------------------------------------- */

static void _shutdown_with_alarm(uint32_t wakeup_timeout_s) {

  LOG_DEBUG("Shutdown with alarm after %d", wakeup_timeout_s);

  bsp_gpio_led_off();
  bsp_gpio_gnss_wakeup_enter();
  bsp_gpio_gnss_off();
  bsp_gpio_lora_off();

  while(bsp_gpio_is_button_pressed()){
	  //Wait for release button to avoid wake-up
  }

  /* Clear Standby flag */
  __HAL_PWR_CLEAR_FLAG(PWR_FLAG_SB);

  /* Disable all used wake-up sources: PWR_WAKEUP_PIN1 */
  HAL_PWR_DisableWakeUpPin(PWR_WAKEUP_PIN1);

  /* Clear all related wake-up flags*/
  __HAL_PWR_CLEAR_FLAG(PWR_FLAG_WU);

  /* Enable WakeUp Pin PWR_WAKEUP_PIN1 connected to PA.0 */
  HAL_PWR_EnableWakeUpPin(PWR_WAKEUP_PIN1);

  if(wakeup_timeout_s > 0) {
	  bsp_rtc_setup_wakeup_timer(wakeup_timeout_s);
  }

  /* Enter the Standby mode */
  HAL_PWR_EnterSTANDBYMode();
}

/* -------------------------------------------------------------------------- */

static void _led_blink_3x(void) {
	for(size_t i=0; i<3; i++) {
		HAL_Delay(300);
		bsp_gpio_led_on();
		HAL_Delay(300);
		bsp_gpio_led_off();
	}
}

/* -------------------------------------------------------------------------- */

static void _led_blink_1x(void) {
	bsp_gpio_led_on();
	HAL_Delay(100);
	bsp_gpio_led_off();
}

/* -------------------------------------------------------------------------- */

#if	(LOG_ENABLED == 1)

static void _log_write(uint8_t *data, size_t size) {

	CDC_Transmit_FS(data, size);
	HAL_Delay(10); //TODO use callback
}

/* -------------------------------------------------------------------------- */

uint64_t get_timestamp64_ms(void) {
    return HAL_GetTick();
}

/* -------------------------------------------------------------------------- */

const log_io_t _log_io = {
    .write = _log_write,
#if LOG_TIMESTAMP_ENABLED == 1U
    .get_ts = get_timestamp64_ms,
#endif
#if LOG_THREADSAFE_ENABLED == 1U
    .lock = _lock,
    .unlock = _unlock,
#endif
};

#endif //LOG_ENABLED

/* -------------------------------------------------------------------------- */

void _parse_lora_response(uint32_t timeout) {

	uint32_t ts =  HAL_GetTick();
	uint8_t queue_item;
	while ( (HAL_GetTick() - ts) < timeout) {
		/* Parse LoRa responses */
		while (!queue_is_empty(QHEAD(_lora_rx_queue))) {
		  int index = 0;
		  char lora_response_array[256];
		  HAL_Delay(200);
		  while (queue_dequeue(QHEAD(_lora_rx_queue), &queue_item, dequeue8)) {
			  lora_response_array[index++] = queue_item;
			  if(index >= sizeof(lora_response_array) || queue_item == '\n') {
				  break;
			  }
		  }
		  /* Just Debug output */
		  LOG_ARRAY_STR(LOG_MASK_DEBUG, LOG_COLOR(LOG_COLOR_BLUE)"LoRA Rx:", lora_response_array, index);
		  LOG_DEBUG("");
		}
	}
}

/* -------------------------------------------------------------------------- */

void _lora_init(void) {

	LOG_INFO("LoRa power on...");
	queue_init(QHEAD(_lora_rx_queue), LORA_RX_QUEUE_SIZE);
	bsp_gpio_lora_on();
	bsp_gpio_lora_reset_enter();
	HAL_Delay(10);
	bsp_gpio_lora_reset_leave();
	_parse_lora_response(500);

	MX_USART1_UART_Init();

	//uint8_t cmd_at[] = "\r\n";
	//bsp_uart_lora_write(cmd_at, strlen((const char*)cmd_at));
	_parse_lora_response(800);

	 uint8_t cmd_test_mode[] = "AT+MODE=TEST\r\n";
	bsp_uart_lora_write(cmd_test_mode, strlen((const char*)cmd_test_mode));
	_parse_lora_response(300);

	const uint8_t cmd_params[] = "AT+TEST=RFCFG,868,SF7,125,12,15,8,ON,OFF,OFF\r\n";
	bsp_uart_lora_write(cmd_params, strlen((const char*)cmd_params));
	_parse_lora_response(400);
}

/* -------------------------------------------------------------------------- */

void _lora_send_data(lwgps_t *gnss, uint32_t voltage_mv) {
	char tx_buff[256];
	int size = snprintf(tx_buff, sizeof(tx_buff),
			"AT+TEST=TXLRSTR,\"ID1=%02lu, ID2=%03lu, lat %lf, lon %lf VBAT %lu\"\r\n",
			g_id1, g_id2, gnss->latitude, gnss->longitude, voltage_mv);

	bsp_uart_lora_write((const uint8_t*)tx_buff, size);
	_parse_lora_response(300);
}

/* -------------------------------------------------------------------------- */

void _shutdown_button_holding_indication(void) {
	  bsp_gpio_led_on();
	  uint32_t ts =  HAL_GetTick();
	  while(bsp_gpio_is_button_pressed()) {
		  if( (HAL_GetTick() - ts) >= LONG_PRES_TIME_MS) {
			  break;
		  }
		  HAL_Delay(50);
		  bsp_gpio_led_toggle();
	  }
	  bsp_gpio_led_off();
}

/* -------------------------------------------------------------------------- */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  HAL_DBGMCU_EnableDBGSleepMode();
  HAL_DBGMCU_EnableDBGStopMode();
  HAL_DBGMCU_EnableDBGStandbyMode();
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_RTC_Init();
  /* USER CODE BEGIN 2 */

  if(bsp_rtc_is_wakeup_activated() == false && bsp_gpio_is_button_pressed() == false) {
	  //Reset or debug entry
  } else if(bsp_rtc_is_wakeup_activated() == false && bsp_gpio_is_button_pressed() == true) {
	  //Power on by button entry
	  bsp_gpio_led_on();
	  uint32_t ts =  HAL_GetTick();
	  while(bsp_gpio_is_button_pressed()) {
		  if( (HAL_GetTick() - ts) >= LONG_PRES_TIME_MS) {
			  break;
		  }
		  bsp_gpio_led_toggle();
	  }
	  bsp_gpio_led_off();

	  if(bsp_gpio_is_button_pressed() == false) {
		  _shutdown();
	  }
  }else if(bsp_rtc_is_wakeup_activated() == true && bsp_gpio_is_button_pressed() == true) {
	  //Wake-up from button but timer working -> shutdown device after 3s
	  _shutdown_button_holding_indication();
	  if(bsp_gpio_is_button_pressed() == true) {
		  _shutdown();
	  } else {
		  _shutdown_with_alarm(0);
	  }
  } else {
	  //Wake-up from timer button not pressed
  }

#if	(LOG_ENABLED == 1)
  MX_USB_DEVICE_Init();
  log_init(LOG_MASK_ALL, &_log_io);
  LOG_INFO("\r\n\r\nLoCoAir Started, %s %s Build %d", __TIME__, __DATE__, 0);
#endif

  _led_blink_3x();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  LOG_INFO("GNSS power on...");
  queue_init(QHEAD(_gnss_rx_queue), GNSS_RX_QUEUE_SIZE);
  bsp_gpio_gnss_on();
  bsp_gpio_gnss_wakeup_leave();
  MX_USART2_UART_Init();
  lwgps_init(&hgnss);

  uint32_t blink_ts =  HAL_GetTick();
  uint32_t no_fix_ts =  HAL_GetTick();
  bool is_button_pressed_last_state = bsp_gpio_is_button_pressed();
  uint8_t queue_item = 0;

  LOG_DEBUG("Wait for GPS Fix...");
  while (1)
  {

#if	(LOG_ENABLED == 1)
	  /* Debug blink period 5s */
	  if( (HAL_GetTick() - blink_ts) >= (5 * 1000ULL)) {
		  blink_ts = HAL_GetTick();
		  _led_blink_1x();

		  LOG_DEBUG("VBAT %d Fix type %d LAT %f LON %f PDOP %f HDOP %f VDOP %f",
				  bsp_adc_get_vbat_mv(),
				  hgnss.fix_mode, hgnss.latitude, hgnss.longitude,
				  hgnss.dop_p, hgnss.dop_h, hgnss.dop_v);
	  }
#endif

	  /* if long time no Fix go to sleep */
	  if( (HAL_GetTick() - no_fix_ts) >= NOFIX_TIMEOUT_MS) {
		  _shutdown_with_alarm(SLEEP_NOFIX_PERIOD_S);
	  }

	  /* Button handling */
	  if(bsp_gpio_is_button_pressed() != is_button_pressed_last_state) {
		  is_button_pressed_last_state = bsp_gpio_is_button_pressed();
		  LOG_INFO("Button state changed - %d", is_button_pressed_last_state);

		  if(is_button_pressed_last_state) {
			  _shutdown_button_holding_indication();
			  if(bsp_gpio_is_button_pressed() == true) {
				  _shutdown();
			  }
		  }
	  }

	  /* Parse NMEA stream */
	  while (queue_dequeue(QHEAD(_gnss_rx_queue), &queue_item, dequeue8)) {

		  /*String buffer*/
		  static int string_index = 0;
		  static char string_array[1024];

		  string_array[string_index] = queue_item;
		  if(string_index >= sizeof(string_array)) {
			  LOG_ERROR("To long NMEA STRING");
		  } else {
			  string_index++;
		  }
		  if(queue_item == '\n') {
			  lwgps_process(&hgnss, string_array, string_index);
			  string_index = 0;
		  }
	  }

	  /* Check GPS data is available  */
	  if(hgnss.fix_mode == 3) {
		  LOG_INFO("GPS fixed, fix type %d", hgnss.fix_mode);
		  _lora_init();
		  g_id1 = HAL_GetTick() / 1000; //Debug demo
		  _lora_send_data(&hgnss, bsp_adc_get_vbat_mv());
		  _shutdown_with_alarm(SLEEP_PERIOD_S);
	  }
	  //"Wait for interrupt" enter MCU core to sleep mode until any interrupt occur
	  __WFI();

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI
                              |RCC_OSCILLATORTYPE_HSI48;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.HSI48State = RCC_HSI48_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1|RCC_PERIPHCLK_USART2
                              |RCC_PERIPHCLK_RTC|RCC_PERIPHCLK_USB;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK2;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_HSI48;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();

  while (1)
  {
	  bsp_gpio_led_toggle();
	  for(uint32_t i=0;i<0xFFFF;i++) {
		  __NOP();
	  }
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
